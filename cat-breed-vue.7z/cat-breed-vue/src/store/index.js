import Vue from "vue";
import Vuex from "vuex";
import axios from "axios";

Vue.use(Vuex, axios);

export default new Vuex.Store({
  state: {
    breeds: [],
    selectedBreed: null
  },

  actions: {
    async getBreedsData({ commit }) {
      await axios
        .get("https://api.thecatapi.com/v1/breeds")
        .then(response => {
          commit("SET_BREEDS", response.data);
        })
        .catch(error => {
          console.log(error);
        });
    }
  },
  mutations: {
    SET_BREEDS: (state, breeds) => {
      state.breeds = breeds;
    },
    SET_SELECTED_BREED: (state, selectedBreed) => {
      state.selectedBreed = selectedBreed;
    }
  }
});
