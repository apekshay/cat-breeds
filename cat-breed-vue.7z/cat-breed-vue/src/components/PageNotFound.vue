<template>
  <v-content>
    <div class="cat-info">
      <v-card class="grey" dark>
        <div>
          <v-card-title class="title"></v-card-title>
          <v-card-text class="white text--primary">
            <p class="no-details">
              {{ pageNotFoundError }}
            </p>
          </v-card-text>
        </div>
        <v-fab-transition>
          <v-btn small v-on:click="goBack()" color="blue" absolute bottom right>
            {{ backButton }}
          </v-btn>
        </v-fab-transition>
      </v-card>
    </div>
  </v-content>
</template>

<script>
import constants from "../constants.json";
export default {
  name: "PageNotFound",
  data() {
    return {
      pageNotFoundError: constants.pageNotFoundError,
      backButton: constants.backButtonText
    };
  },
  methods: {
    goBack: function() {
      this.$router.push("/");
    }
  }
};
</script>
