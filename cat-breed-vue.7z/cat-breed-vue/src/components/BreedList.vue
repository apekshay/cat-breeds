<template>
  <v-content>
    <v-card>
      <v-card-title>
        {{ dataTableTitle }}
        <v-spacer></v-spacer>
        <v-text-field
          v-model="search"
          label="Search"
          single-line
          hide-details
        ></v-text-field>
      </v-card-title>
      <v-data-table
        :headers="headers"
        :items="breeds"
        :search="search"
        :items-per-page="5"
        @click:row="goToDetailsPage"
      ></v-data-table>
    </v-card>
    <div class="top-breeds-button">
      <v-btn block v-on:click="goToTopBreeds()" color="blue">
        {{ showBreedsButtonText }}</v-btn
      >
    </div>
  </v-content>
</template>

<script>
import { mapState } from "vuex";
import constants from "../constants.json";
export default {
  name: "BreedList",
  mounted() {
    this.$store.dispatch("getBreedsData");
  },

  computed: {
    ...mapState(["breeds"])
  },

  data: function() {
    return {
      search: "",
      dataTableTitle: constants.dataTableTitle,
      showBreedsButtonText: constants.showBreedsButtonText,
      headers: [
        {
          text: constants.nameColumnText,
          align: "left",
          value: "name"
        },
        { text: constants.originColumnText, value: "origin" },
        { text: constants.adaptibityColumnText, value: "adaptability" },
        {
          text: constants.lifeSpanColumnText,
          value: "life_span",
          sortable: false
        }
      ]
    };
  },
  methods: {
    goToDetailsPage: function(breed) {
      this.$store.commit("SET_SELECTED_BREED", breed);
      this.$router.push("/details/" + breed.id);
    },
    goToTopBreeds: function() {
      this.$router.push("/category");
    }
  }
};
</script>
<style>
.top-breeds-button {
  margin: 20px 0px;
}
</style>
