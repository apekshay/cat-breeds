<template>
  <v-content>
    <v-card>
      <v-card-title class="text-center justify-center py-6">
        <h1 class="category-title">{{ categoryTitle }}</h1>
      </v-card-title>
      <v-tabs v-model="tab" background-color="primary" dark>
        <v-tab v-for="catBreed in catBreeds" :key="catBreed.tab">
          {{ catBreed.tab }}
        </v-tab>
      </v-tabs>
      <v-tabs-items id="databinding" v-model="tab">
        <v-tab-item v-for="catBreed in catBreeds" :key="catBreed.tab">
          <v-card
            flat
            v-for="category in catBreed.category"
            :key="category.name"
          >
            <v-card-text>{{ category.name }}</v-card-text>
          </v-card>
        </v-tab-item>
      </v-tabs-items>
      <v-fab-transition>
        <v-btn small v-on:click="goBack()" color="blue" absolute bottom right>
          {{ backButtonText }}
        </v-btn>
      </v-fab-transition>
    </v-card>
  </v-content>
</template>

<script>
import { mapState } from "vuex";

import constants from "../constants.json";

export default {
  name: "BreedCategory",
  beforeMount() {
    if (this.$store.state.breeds.length === 0) {
      this.$store.dispatch("getBreedsData");
    }
  },
  computed: {
    ...mapState(["breeds"])
  },
  data() {
    return {
      tab: null,
      categoryTitle: constants.categoryTitle,
      backButtonText: constants.backButtonText,
      catBreeds: [
        {
          tab: constants.childFriendly,
          category: this.childFriendlyBreeds(this.$store.state.breeds)
        },
        {
          tab: constants.dogFriendly,
          category: this.dogFriendlyBreeds(this.$store.state.breeds)
        },
        {
          tab: constants.strangerFriendly,
          category: this.strangerFriendlyBreeds(this.$store.state.breeds)
        }
      ]
    };
  },
  methods: {
    childFriendlyBreeds: function(breeds) {
      return breeds
        .sort((breed1, breed2) => {
          return breed2.child_friendly - breed1.child_friendly;
        })
        .slice(0, 5);
    },
    dogFriendlyBreeds: function(breeds) {
      return breeds
        .sort((breed1, breed2) => {
          return breed2.dog_friendly - breed1.dog_friendly;
        })
        .slice(0, 5);
    },
    strangerFriendlyBreeds: function(breeds) {
      return breeds
        .sort((breed1, breed2) => {
          return breed2.stranger_friendly - breed1.stranger_friendly;
        })
        .slice(0, 5);
    },
    goBack: function() {
      this.$router.push("/");
    }
  }
};
</script>
<style>
.category-title {
  font-size: 1.5rem;
}
</style>
