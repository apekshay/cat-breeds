<template>
  <div class="cat-info-rating">
    <label class="subtitle-2">{{ label }}</label>
    <v-rating
      v-model="rating"
      background-color="purple lighten-3"
      color="purple"
    ></v-rating>
  </div>
</template>

<script>
export default {
  name: "Rating",
  props: ["label", "rating"]
};
</script>
