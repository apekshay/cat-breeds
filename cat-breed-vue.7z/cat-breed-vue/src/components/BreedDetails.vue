<template>
  <v-content>
    <div class="cat-info">
      <v-card class="grey" dark>
        <div v-if="selectedBreed">
          <v-card-title class="title">{{ selectedBreed.name }}</v-card-title>
          <v-card-text class="white text--primary">
            <p class="description">
              {{ selectedBreed.description }}
              <a :href="selectedBreed.wikipedia_url" target="_blank">{{
                findMoreLink
              }}</a>
            </p>

            <div class="cat-info-rating">
              <Rating
                :label="adaptability"
                :rating="selectedBreed.adaptability"
              />
              <Rating
                :label="childFriendly"
                :rating="selectedBreed.child_friendly"
              />
              <Rating
                :label="dogFriendly"
                :rating="selectedBreed.dog_friendly"
              />
            </div>
          </v-card-text>
        </div>
        <div v-if="!selectedBreed">
          <v-card-title class="title"></v-card-title>
          <v-card-text class="white text--primary">
            <p class="no-details">
              {{ noDetailsFoundError }}
            </p>
          </v-card-text>
        </div>
        <v-fab-transition>
          <v-btn small v-on:click="goBack()" color="blue" absolute bottom right>
            {{ backButtonText }}
          </v-btn>
        </v-fab-transition>
      </v-card>
    </div>
  </v-content>
</template>

<script>
import { mapState } from "vuex";
import constants from "../constants.json";
import Rating from "./Rating";
export default {
  name: "BreedDetails",
  beforeMount() {
    if (this.$store.state.breeds.length === 0) {
      this.$store
        .dispatch("getBreedsData")
        .then(() => {
          this.$store.commit(
            "SET_SELECTED_BREED",
            this.breeds.filter(breed => breed.id === this.$route.params.id)[0]
          );
        })
        .catch(error => {
          console.log(error);
        });
    }
  },
  data() {
    return {
      findMoreLink: constants.findMoreLink,
      adaptability: constants.adaptability,
      childFriendly: constants.childFriendly,
      dogFriendly: constants.dogFriendly,
      noDetailsFoundError: constants.noDetailsFoundError,
      backButtonText: constants.backButtonText
    };
  },
  components: {
    Rating
  },
  computed: {
    ...mapState(["breeds", "selectedBreed"])
  },
  methods: {
    goBack: function() {
      this.$router.push("/");
    }
  }
};
</script>
<style>
.title {
  color: black;
}
.description {
  padding: 20px;
  font-size: 1rem;
}
.cat-info {
  display: flex;
  justify-content: center;
}
.goBackButton {
  padding: 20px;
}
.no-details {
  padding: 20px 200px;
}
</style>
