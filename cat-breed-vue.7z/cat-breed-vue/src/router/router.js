import Vue from "vue";
import Router from "vue-router";
import BreedList from "../components/BreedList";
import BreedDetails from "../components/BreedDetails";
import BreedCategory from "../components/BreedCategory";
import PageNotFound from "../components/PageNotFound";

Vue.use(Router);

const router = new Router({
  mode: "history",
  routes: [
    {
      path: "/",
      name: "list",
      component: BreedList
    },
    {
      path: "/details/:id",
      name: "details",
      component: BreedDetails
    },
    {
      path: "/category",
      name: "category",
      component: BreedCategory
    },
    {
      path: "*",
      name: "pageNotFound",
      component: PageNotFound
    }
  ]
});

export default router;
