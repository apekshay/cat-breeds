<template>
  <v-app>
    <v-app-bar app color="cyan" dark>
      <v-spacer />
      <v-toolbar-title>{{ application }}</v-toolbar-title>
    </v-app-bar>
    <div class="content">
      <router-view></router-view>
    </div>
    <v-footer color="cyan" app>
      <v-spacer />
      <span class="white--text">{{ "&copy;" + footerText }}</span>
    </v-footer>
  </v-app>
</template>

<script>
import constants from "./constants.json";
export default {
  name: "App",
  components: {},
  data: function() {
    return {
      footerText: constants.footerText,
      application: constants.application
    };
  }
};
</script>
<style>
.content {
  padding: 20px;
}
</style>
